package atividade02;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        Gato g1 = new Gato("Simba", "Vira-lata");

        Animal gato = new Gato("jnxa", "jskn");
        g1.cacarRato(); //metodo apenas da classe gato

        Cavalo c1 = new Cavalo("Oli", "xalala", true);

        }
    }

