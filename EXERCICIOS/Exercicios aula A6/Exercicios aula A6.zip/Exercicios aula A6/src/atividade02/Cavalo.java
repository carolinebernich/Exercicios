package atividade02;

public class Cavalo extends Animal {

    private boolean ferradura;

    public Cavalo(String nome, String raca, boolean f) {
        super(nome, raca);
        this.ferradura= f;
    }
}
